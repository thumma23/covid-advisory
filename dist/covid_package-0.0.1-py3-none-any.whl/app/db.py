database_cfg = {
    "host" : "covid-db.cg27uroowblc.us-east-2.rds.amazonaws.com",
    "user" : "admin",
    'passwd' : "S3kfamily",
    'database' : "user_db"
}

jwt_cfg = {
    'secret_key' : 'sahith'
}